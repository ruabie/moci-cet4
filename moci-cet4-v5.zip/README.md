# 墨词 · CET-4 V5

V5 重点是把 V4 从“功能完整”推进到“长期使用不容易丢进度”。

## V5 新增
- 智能「今日训练」：根据四维掌握度和当天进度排序学习、拼写、听辨、语境
- 跨设备同步由整份覆盖改为合并：单词调度按较新的记录，维度统计保留样本更多的一侧，每日计数取较大值
- 同步安全：Bearer Token 只保存在当前设备，上传时自动从 state 中剥离
- 可导入“真题/材料训练包”：仅用户导入且带来源的材料显示来源；内置材料始终标注原创
- 导入材料与单词四维掌握度联动；听力条目可提供 audioUrl，缺失时回退 TTS
- 词条页尝试读取公开真题统计元数据（句子数量、覆盖套数/年份、主要题型），不批量复制真题原文
- Service Worker 改为导航网络优先，部署更新后更不容易一直卡在旧版本
- 提供 Netlify / Vercel / GitHub Pages 友好的静态部署文件
- 附 Cloudflare Worker + KV 同步服务示例

## 直接本地测试
在项目目录运行：

`python -m http.server 8080`

然后打开 `http://localhost:8080`。

## iPhone 安装
1. 将本目录部署到 HTTPS。
2. Safari 打开部署地址。
3. 共享 → 添加到主屏幕。

## 真题训练包
设置页可以导入 JSON。模板见 `exam-pack-template.json`。

注意：项目不会把内置生成/原创语境伪装成历年真题。若导入受版权保护的真题，请确保你有权在自己的设备上使用该材料。

## 同步端点
App 仍兼容任意支持 GET/PUT JSON 的 CORS 端点。V5 上传结构：

`{ app, version, updatedAt, state }`

其中 `state.settings.syncToken` 会被自动删除。

`sync-server/` 提供一个 Cloudflare Worker + KV 示例：
- GET `/sync/<profile-id>`
- PUT `/sync/<profile-id>`
- Bearer Token 鉴权
- KV binding: `MOCI_SYNC`

这只是可部署后端示例，不包含任何预置账号或密钥。
